module.exports = {
    devServer: {
	port: 8080,
        disableHostCheck: true
    }
}